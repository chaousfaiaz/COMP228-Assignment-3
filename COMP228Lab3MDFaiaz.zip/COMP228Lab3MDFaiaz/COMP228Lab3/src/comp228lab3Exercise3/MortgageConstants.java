/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp228lab3Exercise3;

/**
 *
 * @author faiaz
 */
public interface MortgageConstants {
	
	//Constants
	
	public final String bankName = "Toronto Dominion Bank";
	public final int maxMortgageAmount = 300000;
	public final int shortTerm = 1;
	public final int midTerm = 3;
	public final int longTerm = 5;
	
	
}